"""Graph nodes."""

